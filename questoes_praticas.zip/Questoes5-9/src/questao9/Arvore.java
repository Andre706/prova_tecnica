/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao9;

/**
 *
 * @author Andre luiz
 */
public class Arvore {
    No noRaiz;
    
    public Arvore(No noRaiz){
       this.noRaiz = noRaiz;
    }
    
    public void insereNo(int valor){
        No no = new No(valor);
        No aux = this.noRaiz;
        
        while(true){
           if(no.valor<aux.valor){
               if(aux.noEsq!=null){
                  aux = aux.noEsq;
               }
               else{
                 aux.noEsq = no;
                 break;
               }
           }
           else if(no.valor>=aux.valor){
                if(aux.noDir!=null){
                    aux = aux.noDir;
                }
                else{
                   aux.noDir = no;
                   break;
                }
           }
        }
    }
    
    
    public static boolean verificaSimilar(Arvore arv1,Arvore arv2){
        return Arvore.verificaSimilar(arv1.noRaiz,arv2.noRaiz);
    }
    
    public static boolean verificaSimilar(No no1,No no2){
       boolean verEsq,verDir;
       
       //verifica se há similaridade no lado direito
       if(no1.noDir==null && no2.noDir==null){
           verDir = true;
       }
       else if(no1.noDir!=null && no2.noDir!=null){ 
           verDir = verificaSimilar(no1.noDir,no2.noDir);
       }
       else{
          verDir = false;
       }
       
      //verifica se há similaridade no lado esquerdo
       if(no1.noEsq==null && no2.noEsq==null){
           verEsq = true;
       }
       else if(no1.noEsq!=null && no2.noEsq!=null){ 
           verEsq = verificaSimilar(no1.noEsq,no2.noEsq);
       }
       else{
            verEsq = false;
       }
       
       if(verEsq && verDir){
          return true;
       }
       else{
         return false;
       }
    }
      
    public static void main(String[] args) {
         Arvore arv1 = new Arvore(new No(15));
         arv1.insereNo(10);
         arv1.insereNo(20);
        arv1.insereNo(9);
         arv1.insereNo(11);
         arv1.insereNo(21);
    
         Arvore arv2 = new Arvore(new No(12));
         arv2.insereNo(9);
         arv2.insereNo(15);
        arv2.insereNo(7);
         arv2.insereNo(10);
         arv2.insereNo(13);
    
         
        System.out.println(Arvore.verificaSimilar(arv1,arv2));
    }
}

    


