/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao7;

/**
 *
 * @author Andre luiz
 */
public class listaEncadeada {
    No noRaiz,ult;
    
    public listaEncadeada(No noRaiz){
        this.noRaiz = noRaiz;
    }
    
    public boolean insereNo(int valor){
       No no = new No(valor);
        
       if(ult==null){ 
         this.noRaiz.prox = no;
         no.ant = this.noRaiz;
       }
       else{
          this.ult.prox = no;
           no.ant = this.ult;
       }
       this.ult = no;
       return true;
    }
    
    public boolean removeNo(int  valor){
        No no = this.buscaNo(valor);
        
        if(no==null){
          return false;
        }
        
        if(no==this.noRaiz){
               this.noRaiz = no.prox;
               no.prox.ant = null;
               no.prox = null;
        }
        
       else if(no==this.ult){
              this.ult = no.ant;
              no.ant.prox = null;
              no.ant = null;
        }
        
       else{
           no.ant.prox = no.prox;
           no.prox.ant = no.ant;
           no.ant = null;
           no.prox = null;
        }
        return true;  
    }
    
    public No buscaNo(int valor){
       No noAux = this.noRaiz;
       
       while(noAux!=null){
          if(noAux.valor==valor){
              return noAux;
          }
          noAux = noAux.prox;
       }
       return null;
    }
    
    public void exibeNos(){
       No noAux = this.noRaiz;
       String espaco="";
       
        while(noAux!=null){
           espaco+=" ";
           System.out.println(espaco+noAux.valor);
           noAux = noAux.prox;
        }
    }
    
   public static void main(String[] args) {
        listaEncadeada lista = new listaEncadeada(new No(1));
        lista.insereNo(2);
         lista.insereNo(3);
         lista.insereNo(4);
         lista.insereNo(5);
         lista.insereNo(6);
         lista.insereNo(7);
         lista.insereNo(8);
         lista.insereNo(9);
         lista.insereNo(10);
         lista.removeNo(4);
         lista.removeNo(9);
         lista.exibeNos(); 
    }
    
}

