/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes5_6_8;

import java.util.Arrays;



/**
 *
 * @author Andre luiz
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    }
    
    
 //Questão 5
    public static boolean verifica5(String str){
       
       int fim = str.length()-1;
       int meio = str.length()/2;
       int crc1,crc2;
       
        if(str.charAt(meio)!='C' || str.length()<3){
           return false;
       }
       
       for(int i=0;i<meio;i++){
           crc1 = str.charAt(i);
           crc2 = str.charAt(fim-i);
           if(crc1!=crc2 || (crc1!='A' && crc2!='B')){
               return false;
           }
       }
       return true;
    }

    
//Questão 6
    public static boolean verifica6(String cad){
       String cadList[] = new String[cad.length()/2 + 1];
       cadList = cad.split("D");
       int fim,meio,crc1,crc2;
       String str;
       
        
       if(cad.charAt(0)=='D' || cad.charAt(cad.length()-1)=='D'){ //cadeia iniciada ou terminada em D estará errada
          return false;
       } 
        
       for(int i=0;i<cadList.length;i++){
           str = cadList[i];
           
           if(str==null){
             break;
           }
          
        fim = str.length()-1;
        meio = str.length()/2;  
        
        if(str.charAt(meio)!='C' || str.length()<3){
           return false;
        }
       
         for(int j=0;j<meio;j++){
            crc1 = str.charAt(j);
            crc2 = str.charAt(fim-j);
            if(crc1!=crc2 || (crc1!='A' && crc2!='B')){
               return false;
            }
         }
      } 

     return true;
    }
    
    //Questão 8
    public static String inverteFrase(String frase){
        String strList[] = new String[frase.length()/2 + 1];
        strList = frase.split(" "); 
        String fraseInvertida="";
   
        for(int i=0;i<strList.length;i++){
             //inverte string e refaz frase
             fraseInvertida+=new StringBuilder(strList[i]).reverse().toString()+" ";
        }
        return fraseInvertida;
    }
}
