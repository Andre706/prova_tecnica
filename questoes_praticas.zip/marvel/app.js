const express = require('express')
const app = new express();
const handlebars = require('express-handlebars')
const bodyParser = require('body-parser')
const fetch = require("node-fetch")

 
//links de conexão com API da Marvel
 const url_personagens = 'https://gateway.marvel.com:443/v1/public/characters?ts=1&apikey=c4638e43ec5c8f3d2a2b1b9b08894f3b&hash=468fcbfa3023c5e449897cbbb526dc88'
 const url_quadrinhos = 'https://gateway.marvel.com:443/v1/public/comics?ts=1&apikey=c4638e43ec5c8f3d2a2b1b9b08894f3b&hash=468fcbfa3023c5e449897cbbb526dc88' 

//configuração handlebars
app.engine('handlebars',handlebars({defaultLayout:'main'}))
  app.set('view engine','handlebars')


//configuração body-parser
app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

       
//rotas
app.get('/personagens',(req,res)=>{
    //pega  dados de cada personagem da API Marvel(nome,imagem e link para site da Marvel)
    fetch(url_personagens).then(res=>res.json()).then((personagens)=>{ 
       res.render('personagens',{personagens:personagens.data.results})  
     })
  })


  app.get('/quadrinhos',(req,res)=>{
    //pega  dados de cada quadrinho da API Marvel(nome,imagem e link para site da Marvel)
    fetch(url_quadrinhos ).then(res=>res.json()).then((quadrinhos)=>{
        res.render('quadrinhos',{quadrinhos:quadrinhos.data.results})
     })
  })


  

app.listen(8990,()=>{
    console.log("servidor rodando na porta 8990")
})  
